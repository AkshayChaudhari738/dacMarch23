class Program_3 {
    public static void main(String[] args) {
        System.out.println("Hello world");
    }
}

// javap -c Program_3.class (For getting bytecode)