/*
 * 31.Read the documentation of NumberFormatException and try to
generate it in Java code.
 */

public class Problem_31 {
    public static void main(String[] args) {
        int i = Integer.parseInt(args[0]);
        
    }
}
