/*
 * 23.Write a program to perform below operations on float type to
get:
a. The number of bits used to represent a float value
b. The number of bytes used to represent a float value
c. The minimum value a float
d. The maximum value a float
 */

public class Problem_23 {
    public static void main(String[] args) {
        // for float
        System.out.println("bits : "+ Float.SIZE);
        System.out.println("bytes : "+ Float.BYTES);
        System.out.println("min value : "+ Float.MIN_VALUE);
        System.out.println("max value : "+ Float.MAX_VALUE);





    }
}
